/*
========================================================================================================================================================================
Name: Kathryn Lim
Class: CPTS 122, Spring 2020: Lab Section
PA1: Fitbit
Date:
Credits: StackOverflow, Caffeine
P.S.: I would like to learn how to use a single function to sum calories, distance, etc. (without using templates) instead of creating a function for each of them
========================================================================================================================================================================
*/

#include "Fitbit.h"

int main() {
	execute();
	return 0;
}